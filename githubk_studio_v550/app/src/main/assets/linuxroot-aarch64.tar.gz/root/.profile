export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export TERM=${TERM:-xterm-256color}
export LANG=${LANG:-C.UTF-8}
alias ls='ls --color=auto' 2>/dev/null
